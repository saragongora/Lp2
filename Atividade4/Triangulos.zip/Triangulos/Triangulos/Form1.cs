﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulos
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;

        private void TxtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
                MessageBox.Show("Número inválido!");
        }

        private void TxtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
                MessageBox.Show("Número inválido!");
        }

        private void BntVerificar_Click(object sender, EventArgs e)
        {
            if (ladoA < (ladoB + ladoC) && ladoA > Math.Abs(ladoB - ladoC) && ladoB < (ladoA + ladoC) && ladoB > Math.Abs(ladoA - ladoC) && ladoC < (ladoA + ladoB) && ladoC > Math.Abs(ladoA - ladoB))
            {
                if (ladoA == ladoB && ladoB == ladoC)
                    MessageBox.Show("Triângulo Equilatero");
                else if (ladoA == ladoB || ladoB == ladoC || ladoA == ladoC)
                    MessageBox.Show("Triângulo Isósceles");
                else if (ladoA != ladoB && ladoB != ladoC)
                    MessageBox.Show("Triângulo Escaleno");
            }

            else
                MessageBox.Show("Valores inválidos");
        }

        private void BntLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();

        }

        private void BntFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
                MessageBox.Show("Número inválido!");
        }
    }
}
