﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BntExecutar_Click(object sender, EventArgs e)
        {
            double[,] vetorNotas = new double[4, 3];
            string aux;
            double [] mediaAluno = new double [4];
            double mediaSala = 0;

            for (var i = 0; i < 4; i++) // para nota aluno
            {
                var indice1 = i + 1;
                for (var j = 0; j < 3; j++)
                {
                    var indice2 = j + 1;
                    aux = Interaction.InputBox("Professor " + indice2 + " - Digite a nota do " + indice1 + "° aluno: ");


                    if (!double.TryParse(aux, out vetorNotas[i, j]) || vetorNotas[i, j] < 0 || vetorNotas[i, j] > 10)
                    {
                        MessageBox.Show("Número inválido!");
                        i--;
                    }

                    mediaAluno[i] += vetorNotas[i, j];
                    
                }

                mediaAluno[i] = mediaAluno[i] / 3;
                mediaSala += mediaAluno[i];
                
            }

            mediaSala = mediaSala/4;

            for (var z = 0; z < 4; z++) 
                {
                var indice3 = z + 1;
                    for (var j = 0; j < 3; j++)
                    {
                    var indice4 = j + 1;
                    lstbxNotas.Items.Add("Aluno " + indice3 + " Nota Professor " + indice4 + ": " + vetorNotas[z, j] + " Média: " + mediaAluno[z]);
                  
                    }
                }

            lstbxNotas.Items.Add("Média da sala: " + mediaSala);
        }
        }
    }
