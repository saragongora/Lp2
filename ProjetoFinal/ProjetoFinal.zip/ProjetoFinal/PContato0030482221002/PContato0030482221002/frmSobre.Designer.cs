﻿namespace PContato0030482221002
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnJesley = new System.Windows.Forms.Button();
            this.btnCamila = new System.Windows.Forms.Button();
            this.btnSara = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnJesley
            // 
            this.btnJesley.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnJesley.Location = new System.Drawing.Point(85, 275);
            this.btnJesley.Name = "btnJesley";
            this.btnJesley.Size = new System.Drawing.Size(160, 76);
            this.btnJesley.TabIndex = 0;
            this.btnJesley.Text = "Jesley";
            this.btnJesley.UseVisualStyleBackColor = true;
            this.btnJesley.Click += new System.EventHandler(this.BtnJesley_Click);
            // 
            // btnCamila
            // 
            this.btnCamila.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCamila.Location = new System.Drawing.Point(288, 274);
            this.btnCamila.Name = "btnCamila";
            this.btnCamila.Size = new System.Drawing.Size(160, 76);
            this.btnCamila.TabIndex = 1;
            this.btnCamila.Text = "Camila";
            this.btnCamila.UseVisualStyleBackColor = true;
            this.btnCamila.Click += new System.EventHandler(this.BtnCamila_Click);
            // 
            // btnSara
            // 
            this.btnSara.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSara.Location = new System.Drawing.Point(494, 275);
            this.btnSara.Name = "btnSara";
            this.btnSara.Size = new System.Drawing.Size(160, 76);
            this.btnSara.TabIndex = 2;
            this.btnSara.Text = "Sara";
            this.btnSara.UseVisualStyleBackColor = true;
            this.btnSara.Click += new System.EventHandler(this.BtnSara_Click);
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PContato0030482221002.Properties.Resources.agente;
            this.ClientSize = new System.Drawing.Size(742, 393);
            this.Controls.Add(this.btnSara);
            this.Controls.Add(this.btnCamila);
            this.Controls.Add(this.btnJesley);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnJesley;
        private System.Windows.Forms.Button btnCamila;
        private System.Windows.Forms.Button btnSara;
    }
}