﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PContato0030482221002
{
    public partial class Form1 : Form
    {
        public static SqlConnection conexao;

        public Form1()
        {
            InitializeComponent();
        }

        private void SairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=Apolo;Initial Catalog=LP2;User ID=BD2221002;password=Ds211072#");
                conexao.Open();
            }

            catch (SqlException ex)
            {
                MessageBox.Show("Erro no banco de dados =/" + ex.Message);
            }

            catch (Exception ex)
            {
                MessageBox.Show("Outros erros =/" + ex.Message);
            }
        }

        private void CidadeToolStripMenuItem_Click(object sender, EventArgs e)
        { 
            if (Application.OpenForms.OfType<frmCidade>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe.");
                Application.OpenForms["frmCidade"].BringToFront();
            }
            else
            {
                frmCidade objRonaldinho = new frmCidade();
                objRonaldinho.MdiParent = this;
                objRonaldinho.WindowState = FormWindowState.Maximized;
                objRonaldinho.Show();
            }

        }

        private void ContatoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe.");
                Application.OpenForms["frmContato"].BringToFront();
            }
            else
            {
                frmContato objGeralda = new frmContato();
                objGeralda.MdiParent = this;
                objGeralda.WindowState = FormWindowState.Maximized;
                objGeralda.Show();
            }
        }

        private void SobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSobre>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe.");
                Application.OpenForms["frmSobre"].BringToFront();
            }

            else
            {
                frmSobre objTanjiro = new frmSobre();
                objTanjiro.MdiParent = this;
                objTanjiro.WindowState = FormWindowState.Maximized;
                objTanjiro.Show();
            }
        }
    }
}
