﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PContato0030482221002
{
    public partial class frmSobre : Form
    {
        public frmSobre()
        {
            InitializeComponent();
        }

        private void BtnJesley_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmJesley>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe.");
                Application.OpenForms["frmJesley"].BringToFront();
            }
            else
            {
                frmJesley objJesley = new frmJesley();
                objJesley.Show();
            }
        }

        private void BtnCamila_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmCamila>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe.");
                Application.OpenForms["frmCamila"].BringToFront();
            }
            else
            {
                frmCamila objCamila = new frmCamila();
                objCamila.Show();
            }
        }

        private void BtnSara_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmSara>().Count() > 0)
            {
                MessageBox.Show("Formulário já existe.");
                Application.OpenForms["frmSara"].BringToFront();
            }
            else
            {
                frmSara objSara = new frmSara();
                objSara.Show();
            }
        }
    }
}
