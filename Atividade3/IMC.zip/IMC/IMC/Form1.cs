﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IMC
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;

        private void TxtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out altura))
                MessageBox.Show("Número inválido!");
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if (double.TryParse(txtAltura.Text, out altura) && double.TryParse(txtPeso.Text, out peso))
            {
                if (peso <= 0 || altura <= 0)
                    MessageBox.Show("Número inválido");
                else
                {

                    imc = peso / (Math.Pow(altura, 2));

                    if (imc < 18.5)
                        MessageBox.Show(imc.ToString("N1"), "Magreza");

                    else if (imc <= 24.9)
                        MessageBox.Show(imc.ToString("N1"), "Normal");

                    else if (imc <= 29.9)
                        MessageBox.Show(imc.ToString("N1"), "Sobrepeso - Grau I");

                    else if (imc <= 39.9)
                        MessageBox.Show(imc.ToString("N1"), "Obesidade - Grau II");

                    else if (imc <= 40)
                        MessageBox.Show(imc.ToString("N1"), "Obesidade Grave - Grau III");
                }
            }

            else
                MessageBox.Show("Numeros inválidos");

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BntLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAltura.Clear();
        }

        private void BntFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso))
                MessageBox.Show("Número inválido!");
        }
    }
}
