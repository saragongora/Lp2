﻿namespace PMenu
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.richtxt1 = new System.Windows.Forms.RichTextBox();
            this.btnLetras = new System.Windows.Forms.Button();
            this.btnEspaBranco = new System.Windows.Forms.Button();
            this.btnNumeros = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // richtxt1
            // 
            this.richtxt1.Location = new System.Drawing.Point(303, 126);
            this.richtxt1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.richtxt1.Name = "richtxt1";
            this.richtxt1.Size = new System.Drawing.Size(481, 116);
            this.richtxt1.TabIndex = 0;
            this.richtxt1.Text = "";
            // 
            // btnLetras
            // 
            this.btnLetras.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLetras.Location = new System.Drawing.Point(679, 302);
            this.btnLetras.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnLetras.Name = "btnLetras";
            this.btnLetras.Size = new System.Drawing.Size(169, 101);
            this.btnLetras.TabIndex = 9;
            this.btnLetras.Text = "Quantas letras";
            this.btnLetras.UseVisualStyleBackColor = true;
            this.btnLetras.Click += new System.EventHandler(this.btnLetras_Click);
            // 
            // btnEspaBranco
            // 
            this.btnEspaBranco.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEspaBranco.Location = new System.Drawing.Point(476, 302);
            this.btnEspaBranco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnEspaBranco.Name = "btnEspaBranco";
            this.btnEspaBranco.Size = new System.Drawing.Size(169, 101);
            this.btnEspaBranco.TabIndex = 8;
            this.btnEspaBranco.Text = "Localizar 1° espaço em branco";
            this.btnEspaBranco.UseVisualStyleBackColor = true;
            this.btnEspaBranco.Click += new System.EventHandler(this.btnEspaBranco_Click);
            // 
            // btnNumeros
            // 
            this.btnNumeros.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNumeros.Location = new System.Drawing.Point(277, 302);
            this.btnNumeros.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNumeros.Name = "btnNumeros";
            this.btnNumeros.Size = new System.Drawing.Size(169, 101);
            this.btnNumeros.TabIndex = 7;
            this.btnNumeros.Text = "Quantos números";
            this.btnNumeros.UseVisualStyleBackColor = true;
            this.btnNumeros.Click += new System.EventHandler(this.BtnNumeros_Click);
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 567);
            this.Controls.Add(this.btnLetras);
            this.Controls.Add(this.btnEspaBranco);
            this.Controls.Add(this.btnNumeros);
            this.Controls.Add(this.richtxt1);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmExercicio4";
            this.Text = "Exercício 4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox richtxt1;
        private System.Windows.Forms.Button btnLetras;
        private System.Windows.Forms.Button btnEspaBranco;
        private System.Windows.Forms.Button btnNumeros;
    }
}