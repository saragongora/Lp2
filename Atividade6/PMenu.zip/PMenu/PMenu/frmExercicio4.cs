﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void BtnNumeros_Click(object sender, EventArgs e)
        {

            int contador=0, i;
            string texto = richtxt1.Text;

            for (i=0; i < texto.Length; i++)
            {
                if (Char.IsNumber(texto[i]))
                {
                    contador +=  1;
                }
            }

            var contString = Convert.ToString(contador);
        
            MessageBox.Show("Existem "+ contString + " números no texto digitado.");
        }

        private void btnEspaBranco_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            while (posicao <richtxt1.Text.Length && !char.IsWhiteSpace(richtxt1.Text[posicao]))
            {
                posicao++;
            }

            if (posicao >= richtxt1.Text.Length)
                MessageBox.Show("Não há espaços em branco no texto digitado");

            else
                MessageBox.Show("O primeiro espaço em branco está na posição " +posicao);
        }

        private void btnLetras_Click(object sender, EventArgs e)
        {
            int contador = 0;

            char[] vetor = richtxt1.Text.ToCharArray(); 
            
            foreach (char c in vetor)
            {
                if (Char.IsLetter(c))
                {
                    contador += 1;
                }
            }

            var contString = Convert.ToString(contador);

            MessageBox.Show("Existem " + contString + " letras no texto digitado.");
        }
    }
}
