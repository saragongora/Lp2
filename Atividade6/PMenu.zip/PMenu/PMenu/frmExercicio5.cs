﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMenu
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnSortear_Click(object sender, EventArgs e)
        {
            int num1, num2;

            if (int.TryParse(txtPalavra1.Text, out num1) && int.TryParse(txtPalavra2.Text, out num2))
            {
                if (num1 > num2)
                {
                    MessageBox.Show("O número 2 deve ser maior que o número 1!");
                }

                else
                {
                    System.Random Random = new System.Random();
                    int num = Random.Next(num1, num2);
                    MessageBox.Show("O número sorteado é: " +num);
                }
            }
            else
                MessageBox.Show("Número inválido!");
        }
    }
}
