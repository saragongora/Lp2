﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mskbxSalario = new System.Windows.Forms.MaskedTextBox();
            this.panelCasado = new System.Windows.Forms.Panel();
            this.ckbxCasado = new System.Windows.Forms.CheckBox();
            this.gbxSexo = new System.Windows.Forms.GroupBox();
            this.rbntM = new System.Windows.Forms.RadioButton();
            this.rbntF = new System.Windows.Forms.RadioButton();
            this.txtAliqINSS = new System.Windows.Forms.TextBox();
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.nupFilhos = new System.Windows.Forms.NumericUpDown();
            this.bntVerificar = new System.Windows.Forms.Button();
            this.lblDados = new System.Windows.Forms.Label();
            this.lblAliqINSS = new System.Windows.Forms.Label();
            this.lblAliqIRPF = new System.Windows.Forms.Label();
            this.txtAliqIRPF = new System.Windows.Forms.TextBox();
            this.lblSalLiq = new System.Windows.Forms.Label();
            this.txtSalLiq = new System.Windows.Forms.TextBox();
            this.lblSalFam = new System.Windows.Forms.Label();
            this.txtSalFam = new System.Windows.Forms.TextBox();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.panelCasado.SuspendLayout();
            this.gbxSexo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // mskbxSalario
            // 
            this.mskbxSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mskbxSalario.Location = new System.Drawing.Point(225, 86);
            this.mskbxSalario.Margin = new System.Windows.Forms.Padding(4);
            this.mskbxSalario.Name = "mskbxSalario";
            this.mskbxSalario.Size = new System.Drawing.Size(169, 26);
            this.mskbxSalario.TabIndex = 0;
            this.mskbxSalario.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MskbxSalario_MaskInputRejected);
            // 
            // panelCasado
            // 
            this.panelCasado.Controls.Add(this.ckbxCasado);
            this.panelCasado.Location = new System.Drawing.Point(664, 134);
            this.panelCasado.Margin = new System.Windows.Forms.Padding(4);
            this.panelCasado.Name = "panelCasado";
            this.panelCasado.Size = new System.Drawing.Size(227, 80);
            this.panelCasado.TabIndex = 1;
            // 
            // ckbxCasado
            // 
            this.ckbxCasado.AutoSize = true;
            this.ckbxCasado.Location = new System.Drawing.Point(43, 31);
            this.ckbxCasado.Margin = new System.Windows.Forms.Padding(4);
            this.ckbxCasado.Name = "ckbxCasado";
            this.ckbxCasado.Size = new System.Drawing.Size(78, 21);
            this.ckbxCasado.TabIndex = 0;
            this.ckbxCasado.Text = "Casado";
            this.ckbxCasado.UseVisualStyleBackColor = true;
            // 
            // gbxSexo
            // 
            this.gbxSexo.Controls.Add(this.rbntM);
            this.gbxSexo.Controls.Add(this.rbntF);
            this.gbxSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbxSexo.Location = new System.Drawing.Point(664, 25);
            this.gbxSexo.Margin = new System.Windows.Forms.Padding(4);
            this.gbxSexo.Name = "gbxSexo";
            this.gbxSexo.Padding = new System.Windows.Forms.Padding(4);
            this.gbxSexo.Size = new System.Drawing.Size(227, 103);
            this.gbxSexo.TabIndex = 2;
            this.gbxSexo.TabStop = false;
            this.gbxSexo.Text = "Sexo";
            // 
            // rbntM
            // 
            this.rbntM.AutoSize = true;
            this.rbntM.Location = new System.Drawing.Point(43, 63);
            this.rbntM.Margin = new System.Windows.Forms.Padding(4);
            this.rbntM.Name = "rbntM";
            this.rbntM.Size = new System.Drawing.Size(44, 24);
            this.rbntM.TabIndex = 1;
            this.rbntM.TabStop = true;
            this.rbntM.Text = "M";
            this.rbntM.UseVisualStyleBackColor = true;
            // 
            // rbntF
            // 
            this.rbntF.AutoSize = true;
            this.rbntF.Checked = true;
            this.rbntF.Location = new System.Drawing.Point(43, 27);
            this.rbntF.Margin = new System.Windows.Forms.Padding(4);
            this.rbntF.Name = "rbntF";
            this.rbntF.Size = new System.Drawing.Size(40, 24);
            this.rbntF.TabIndex = 0;
            this.rbntF.TabStop = true;
            this.rbntF.Text = "F";
            this.rbntF.UseVisualStyleBackColor = true;
            // 
            // txtAliqINSS
            // 
            this.txtAliqINSS.Enabled = false;
            this.txtAliqINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAliqINSS.Location = new System.Drawing.Point(215, 388);
            this.txtAliqINSS.Margin = new System.Windows.Forms.Padding(4);
            this.txtAliqINSS.Name = "txtAliqINSS";
            this.txtAliqINSS.Size = new System.Drawing.Size(200, 26);
            this.txtAliqINSS.TabIndex = 3;
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(47, 36);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(163, 20);
            this.lblNome.TabIndex = 4;
            this.lblNome.Text = "Nome do funcionário";
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(225, 33);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(383, 26);
            this.txtNome.TabIndex = 5;
            this.txtNome.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtNome_KeyPress);
            this.txtNome.Validated += new System.EventHandler(this.TxtNome_Validated);
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalario.Location = new System.Drawing.Point(47, 90);
            this.lblSalario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(107, 20);
            this.lblSalario.TabIndex = 6;
            this.lblSalario.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilhos.Location = new System.Drawing.Point(47, 148);
            this.lblFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(136, 20);
            this.lblFilhos.TabIndex = 7;
            this.lblFilhos.Text = "Número de filhos";
            // 
            // nupFilhos
            // 
            this.nupFilhos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nupFilhos.Location = new System.Drawing.Point(225, 143);
            this.nupFilhos.Margin = new System.Windows.Forms.Padding(4);
            this.nupFilhos.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.nupFilhos.Name = "nupFilhos";
            this.nupFilhos.Size = new System.Drawing.Size(68, 26);
            this.nupFilhos.TabIndex = 8;
            // 
            // bntVerificar
            // 
            this.bntVerificar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bntVerificar.Location = new System.Drawing.Point(332, 250);
            this.bntVerificar.Margin = new System.Windows.Forms.Padding(4);
            this.bntVerificar.Name = "bntVerificar";
            this.bntVerificar.Size = new System.Drawing.Size(291, 54);
            this.bntVerificar.TabIndex = 9;
            this.bntVerificar.Text = "Verificar Desconto";
            this.bntVerificar.UseVisualStyleBackColor = true;
            this.bntVerificar.Click += new System.EventHandler(this.BntVerificar_Click);
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.lblDados.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDados.Location = new System.Drawing.Point(47, 328);
            this.lblDados.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(15, 20);
            this.lblDados.TabIndex = 10;
            this.lblDados.Text = "-";
            // 
            // lblAliqINSS
            // 
            this.lblAliqINSS.AutoSize = true;
            this.lblAliqINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqINSS.Location = new System.Drawing.Point(47, 395);
            this.lblAliqINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliqINSS.Name = "lblAliqINSS";
            this.lblAliqINSS.Size = new System.Drawing.Size(112, 20);
            this.lblAliqINSS.TabIndex = 11;
            this.lblAliqINSS.Text = "Aliquota INSS";
            // 
            // lblAliqIRPF
            // 
            this.lblAliqIRPF.AutoSize = true;
            this.lblAliqIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliqIRPF.Location = new System.Drawing.Point(47, 447);
            this.lblAliqIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAliqIRPF.Name = "lblAliqIRPF";
            this.lblAliqIRPF.Size = new System.Drawing.Size(111, 20);
            this.lblAliqIRPF.TabIndex = 13;
            this.lblAliqIRPF.Text = "Aliquota IRPF";
            // 
            // txtAliqIRPF
            // 
            this.txtAliqIRPF.Enabled = false;
            this.txtAliqIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAliqIRPF.Location = new System.Drawing.Point(215, 439);
            this.txtAliqIRPF.Margin = new System.Windows.Forms.Padding(4);
            this.txtAliqIRPF.Name = "txtAliqIRPF";
            this.txtAliqIRPF.Size = new System.Drawing.Size(200, 26);
            this.txtAliqIRPF.TabIndex = 12;
            // 
            // lblSalLiq
            // 
            this.lblSalLiq.AutoSize = true;
            this.lblSalLiq.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalLiq.Location = new System.Drawing.Point(47, 550);
            this.lblSalLiq.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalLiq.Name = "lblSalLiq";
            this.lblSalLiq.Size = new System.Drawing.Size(120, 20);
            this.lblSalLiq.TabIndex = 17;
            this.lblSalLiq.Text = "Salário Líquido";
            // 
            // txtSalLiq
            // 
            this.txtSalLiq.Enabled = false;
            this.txtSalLiq.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalLiq.Location = new System.Drawing.Point(215, 543);
            this.txtSalLiq.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalLiq.Name = "txtSalLiq";
            this.txtSalLiq.Size = new System.Drawing.Size(200, 26);
            this.txtSalLiq.TabIndex = 16;
            // 
            // lblSalFam
            // 
            this.lblSalFam.AutoSize = true;
            this.lblSalFam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalFam.Location = new System.Drawing.Point(47, 498);
            this.lblSalFam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalFam.Name = "lblSalFam";
            this.lblSalFam.Size = new System.Drawing.Size(120, 20);
            this.lblSalFam.TabIndex = 15;
            this.lblSalFam.Text = "Salário Família";
            // 
            // txtSalFam
            // 
            this.txtSalFam.Enabled = false;
            this.txtSalFam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSalFam.Location = new System.Drawing.Point(215, 491);
            this.txtSalFam.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalFam.Name = "txtSalFam";
            this.txtSalFam.Size = new System.Drawing.Size(200, 26);
            this.txtSalFam.TabIndex = 14;
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescIRPF.Location = new System.Drawing.Point(521, 447);
            this.lblDescIRPF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(123, 20);
            this.lblDescIRPF.TabIndex = 21;
            this.lblDescIRPF.Text = "Desconto IRPF";
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Enabled = false;
            this.txtDescIRPF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescIRPF.Location = new System.Drawing.Point(680, 443);
            this.txtDescIRPF.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(200, 26);
            this.txtDescIRPF.TabIndex = 20;
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescINSS.Location = new System.Drawing.Point(521, 395);
            this.lblDescINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(124, 20);
            this.lblDescINSS.TabIndex = 19;
            this.lblDescINSS.Text = "Desconto INSS";
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Enabled = false;
            this.txtDescINSS.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDescINSS.Location = new System.Drawing.Point(680, 391);
            this.txtDescINSS.Margin = new System.Windows.Forms.Padding(4);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(200, 26);
            this.txtDescINSS.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(959, 650);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.txtDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.lblSalLiq);
            this.Controls.Add(this.txtSalLiq);
            this.Controls.Add(this.lblSalFam);
            this.Controls.Add(this.txtSalFam);
            this.Controls.Add(this.lblAliqIRPF);
            this.Controls.Add(this.txtAliqIRPF);
            this.Controls.Add(this.lblAliqINSS);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.bntVerificar);
            this.Controls.Add(this.nupFilhos);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.txtAliqINSS);
            this.Controls.Add(this.gbxSexo);
            this.Controls.Add(this.panelCasado);
            this.Controls.Add(this.mskbxSalario);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Calcular Salário";
            this.panelCasado.ResumeLayout(false);
            this.panelCasado.PerformLayout();
            this.gbxSexo.ResumeLayout(false);
            this.gbxSexo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nupFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MaskedTextBox mskbxSalario;
        private System.Windows.Forms.Panel panelCasado;
        private System.Windows.Forms.GroupBox gbxSexo;
        private System.Windows.Forms.RadioButton rbntF;
        private System.Windows.Forms.TextBox txtAliqINSS;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.RadioButton rbntM;
        private System.Windows.Forms.CheckBox ckbxCasado;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.NumericUpDown nupFilhos;
        private System.Windows.Forms.Button bntVerificar;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Label lblAliqINSS;
        private System.Windows.Forms.Label lblAliqIRPF;
        private System.Windows.Forms.TextBox txtAliqIRPF;
        private System.Windows.Forms.Label lblSalLiq;
        private System.Windows.Forms.TextBox txtSalLiq;
        private System.Windows.Forms.Label lblSalFam;
        private System.Windows.Forms.TextBox txtSalFam;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.TextBox txtDescINSS;
    }
}

