﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        double salario, aliqINSS, aliqIRPF, salFam, SalLiq, desINSS, desIRPF;

        int nFilhos;
      
        public Form1()
        {
            InitializeComponent();
        }

       
        private void MskbxSalario_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            if (!double.TryParse(mskbxSalario.Text, out salario))
                MessageBox.Show("Número inválido!");
        }

        private void BntVerificar_Click(object sender, EventArgs e)
        {

            if (double.TryParse(mskbxSalario.Text, out salario) && (salario >= 0))
            {
                {
                    // Aliquota INSS
                    if (salario <= 800.47)
                    {
                        aliqINSS = 0.0765;
                        txtAliqINSS.Text = aliqINSS.ToString("P");
                    }

                    else if (salario <= 1050)
                    {
                        aliqINSS = 0.0865;
                        txtAliqINSS.Text = aliqINSS.ToString("P");
                    }

                    else if (salario <= 1400.77)
                    {
                        aliqINSS = 0.09;
                        txtAliqINSS.Text = aliqINSS.ToString("P");
                    }

                    else if (salario <= 2801.56)
                    {
                        aliqINSS = 0.11;
                        txtAliqINSS.Text = aliqINSS.ToString("P");
                    }

                    else
                    {
                        aliqINSS = 308.17;
                        txtAliqINSS.Text = aliqINSS.ToString();
                    }
                }

                {
                    // Aliquota IRPF
                    if (salario <= 1257.12)
                    {
                        aliqIRPF = 0;
                        txtAliqIRPF.Text = ("Isento");
                    }

                    else if (salario <= 2512.08)
                    {
                        aliqIRPF = 0.15;
                        txtAliqIRPF.Text = aliqIRPF.ToString("P");
                    }

                    else
                    {
                        aliqIRPF = 0.275;
                        txtAliqIRPF.Text = aliqIRPF.ToString("P");
                    }

                }

                {
                    // Salário Familia
                    if (salario <= 435.52)
                    {
                        int.TryParse(nupFilhos.Text, out nFilhos);
                        salFam = 22.33 * nFilhos;
                        txtSalFam.Text = salFam.ToString("C");
                    }

                    else if (salario <= 654.61)
                    {
                        int.TryParse(nupFilhos.Text, out nFilhos);
                        salFam = 15.74 * nFilhos;
                        txtSalFam.Text = salFam.ToString("C");
                    }

                    else
                    {
                        int.TryParse(nupFilhos.Text, out nFilhos);
                        salFam = 0;
                        txtSalFam.Text = salFam.ToString("C");
                    }
                }

                //Descontos
                if (salario > 2801.56)
                {
                    desINSS = aliqINSS;
                }

                else
                {
                    desINSS = salario * aliqINSS;
                }
                
                txtDescINSS.Text = desINSS.ToString("C");
                desIRPF = salario * aliqIRPF;
                txtDescIRPF.Text = desIRPF.ToString("C");

                SalLiq = salario - desINSS - desIRPF + salFam;
                txtSalLiq.Text = SalLiq.ToString("C");

                {

                    // lbl Dados
                    if (rbntF.Checked)
                    {
                        if (ckbxCasado.Checked)
                        {
                            if (nupFilhos.Value == 0)
                            {
                                lblDados.Text = ("Os descontos do salário da Sra " + txtNome.Text + " que é casada e não tem filhos é: ");
                            }

                            else if (nupFilhos.Value == 1)
                            {
                                lblDados.Text = ("Os descontos do salário da Sra " + txtNome.Text + " que é casada e tem 1 filho é: ");
                            }

                            else
                            {
                                lblDados.Text = ("Os descontos do salário da Sra " + txtNome.Text + " que é casada e tem " + nupFilhos.Value + " filhos é: ");
                            }
                        }

                        else
                        {
                            if (nupFilhos.Value == 0)
                            {
                                lblDados.Text = ("Os descontos do salário da Sra " + txtNome.Text + " que é solteira e não tem filhos é: ");
                            }

                            else if (nupFilhos.Value == 1)
                            {
                                lblDados.Text = ("Os descontos do salário da Sra " + txtNome.Text + " que é solteira e tem 1 filho é: ");
                            }

                            else
                            {
                                lblDados.Text = ("Os descontos do salário da Sra " + txtNome.Text + " que é solteira e tem " + nupFilhos.Value + " filhos é: ");
                            }
                        }

                    }

                    else
                    {
                        if (ckbxCasado.Checked)
                        {
                            if (nupFilhos.Value == 0)
                            {
                                lblDados.Text = ("Os descontos do salário do Sr " + txtNome.Text + " que é casado e não tem filhos é: ");
                            }

                            else if (nupFilhos.Value == 1)
                            {
                                lblDados.Text = ("Os descontos do salário do Sr " + txtNome.Text + " que é casado e tem 1 filho é: ");
                            }

                            else
                            {
                                lblDados.Text = ("Os descontos do salário do Sr " + txtNome.Text + " que é casado e tem " + nupFilhos.Value + " filhos é: ");
                            }
                        }

                        else
                        {
                            if (nupFilhos.Value == 0)
                            {
                                lblDados.Text = ("Os descontos do salário do Sr " + txtNome.Text + " que é solteiro e não tem filhos é: ");
                            }

                            else if (nupFilhos.Value == 1)
                            {
                                lblDados.Text = ("Os descontos do salário do Sr " + txtNome.Text + " que é solteiro e tem 1 filho é: ");
                            }

                            else
                            {
                                lblDados.Text = ("Os descontos do salário do Sr " + txtNome.Text + " que é solteiro e tem " + nupFilhos.Value + " filhos é: ");
                            }
                        }
                    }
                }

            }
            else
            {
                MessageBox.Show("Salário inválido");
            }

        }

        private void TxtNome_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(Char.IsNumber(e.KeyChar) || Char.IsPunctuation(e.KeyChar))
            {
                MessageBox.Show("Nome inválido");
            }
        }

        private void TxtNome_Validated(object sender, EventArgs e)
        {
            if(txtNome.Text.Length < 10)
            {
                MessageBox.Show("Nome não pode ter menos de 10 caracteres");
                txtNome.Focus();
            }
        }
    }
}
